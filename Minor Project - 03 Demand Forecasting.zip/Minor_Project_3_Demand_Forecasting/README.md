# Demand Forecasting System

## Project Description
A machine learning demonstration for estimating
future sales demand from historical sample data.

## Technologies Used
- Python
- Pandas
- NumPy
- Scikit-learn
- Streamlit

## Features
- Historical sales inputs
- Past sales lag features
- Future demand estimation

## How To Run
1. Install requirements.
2. Run train_model.py.
3. Run app.py using Streamlit.

## Disclaimer
Uses synthetic data for educational purposes.