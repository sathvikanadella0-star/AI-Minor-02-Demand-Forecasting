import streamlit as st
import pandas as pd
import joblib
import os

st.set_page_config(
    page_title="Demand Forecasting",
    page_icon="📈"
)

st.title("📈 Demand Forecasting System")

st.write(
    "Estimate future sales demand using sample historical data."
)

MODEL_PATH = "demand_model.pkl"

if not os.path.exists(MODEL_PATH):
    st.error("Model Missing. First Run train_model.py")
    st.stop()

model = joblib.load(MODEL_PATH)

st.subheader("Enter Historical Sales Values")

day = st.number_input(
    "Forecast Day Number",
    min_value=15,
    max_value=10000,
    value=731
)

lag_1 = st.number_input(
    "Previous Day Sales",
    min_value=0.0,
    value=120.0
)

lag_7 = st.number_input(
    "Sales 7 Days Ago",
    min_value=0.0,
    value=110.0
)

lag_14 = st.number_input(
    "Sales 14 Days Ago",
    min_value=0.0,
    value=115.0
)

day_of_week = st.selectbox(
    "Day Of Week",
    options=list(range(7)),
    format_func=lambda x: [
        "Monday",
        "Tuesday",
        "Wednesday",
        "Thursday",
        "Friday",
        "Saturday",
        "Sunday"
    ][x]
)

if st.button("Forecast Demand"):

    features = pd.DataFrame([{
        "day": day,
        "lag_1": lag_1,
        "lag_7": lag_7,
        "lag_14": lag_14,
        "day_of_week": day_of_week
    }])

    prediction = model.predict(features)[0]

    st.success(
        f"Estimated Demand: {prediction:.2f} Units"
    )

    st.caption(
        "Educational demonstration using synthetic data. "
        "Not a validated business forecast."
    )