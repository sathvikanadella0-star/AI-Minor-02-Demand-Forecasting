import numpy as np
import pandas as pd
import joblib

from sklearn.ensemble import RandomForestRegressor

np.random.seed(42)

# Create Sample Historical Sales Data
days = np.arange(1, 731)

weekly_pattern = 20 * np.sin(
    2 * np.pi * days / 7
)

yearly_pattern = 30 * np.sin(
    2 * np.pi * days / 365
)

trend = 0.05 * days

noise = np.random.normal(0, 8, len(days))

sales = (
    100
    + weekly_pattern
    + yearly_pattern
    + trend
    + noise
)

sales = np.maximum(sales, 0)

data = pd.DataFrame({
    "day": days,
    "sales": sales
})

# Create Past Sales Features
data["lag_1"] = data["sales"].shift(1)
data["lag_7"] = data["sales"].shift(7)
data["lag_14"] = data["sales"].shift(14)

data["day_of_week"] = (
    data["day"] % 7
)

data = data.dropna().reset_index(drop=True)

features = [
    "day",
    "lag_1",
    "lag_7",
    "lag_14",
    "day_of_week"
]

X = data[features]
y = data["sales"]

model = RandomForestRegressor(
    n_estimators=100,
    random_state=42
)

model.fit(X, y)

joblib.dump(model, "demand_model.pkl")

data.to_csv("demand_data.csv", index=False)

print("Demand Forecasting Model Created Successfully!")